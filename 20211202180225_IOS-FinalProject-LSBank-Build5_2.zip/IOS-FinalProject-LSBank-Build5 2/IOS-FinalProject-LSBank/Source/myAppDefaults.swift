//
//  appDefaults.swift
//  IOS-FinalProject-LSBank
//
//  Created by user203175 on 11/5/21.
//

import Foundation
import UIKit

class MyAppDefaults {
    
    enum LayerCornerRadius {
        
        static let button : CGFloat = 10
        
        static let topViewContainer : CGFloat = 10
        
    }

    
    
}




