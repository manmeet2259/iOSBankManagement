//
//  enumSegue.swift
//  IOS-FinalProject-LSBank
//
//  Created by user203175 on 10/22/21.
//

import Foundation

enum Segue {
        
    static let toMainView = "toMainView"
    static let toAccountActivationView = "toAccountActivationView"
    static let toPayeesView = "toPayeesView"
    static let toNewPayeeView = "toNewPayeeView"
    static let toSendMoneyView = "toSendMoneyView"

}
